// floatingSearch.js
//
// 모든 페이지 우측 하단에 떠 있는 검색 버튼 + 팝업. search.html(search.js)과 완전히
// 같은 검색(메일/메신저 GraphRAG 질의 → /run-query-async → /job-status 폴링)을
// 그대로 재사용해서, 어느 페이지에서든 실제 검색 페이지와 동일한 결과를 즉시 볼 수 있게 한다.
// main-app.js에서 side-effect import되므로, main-app.js를 쓰는 모든 페이지(로그인 페이지
// 제외)에 자동으로 뜬다 — 페이지마다 따로 붙일 필요 없음.
import { getApiBase } from "../utils/apiBase.js";

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
function escapeAttr(str) {
  return String(str || "")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function pollJob(
  FLASK_URL,
  jobId,
  onDone,
  onError,
  interval = 2000,
  maxTries = 60,
) {
  for (let i = 0; i < maxTries; i++) {
    await new Promise((r) => setTimeout(r, interval));
    try {
      const res = await fetch(`${FLASK_URL}/job-status/${jobId}`);
      const data = await res.json();
      if (data.status === "done") {
        onDone(data.result || "결과가 없습니다.", data.source_ids || []);
        return;
      }
      if (data.status === "error") {
        onError(data.result || "오류가 발생했습니다.");
        return;
      }
    } catch (e) {
      onError("서버 연결에 실패했습니다.");
      return;
    }
  }
  onError("응답 시간이 초과되었습니다. 다시 시도해주세요.");
}

// 요청 — 시연 영상용으로 플로팅 검색(메신저 탭)에서 특정 질문 하나만
// 실제 GraphRAG 호출 없이 미리 써둔 답변으로 바로 뜨도록 하드코딩. "3학년 4반
// 고등학교 단톡방"의 2022년 9월 요약(HS_MONTH_TEXT_OVERRIDES, seed_fake_people.py)에
// "학교에서 다같이 영화를 보던 날도 있었고"라는 내용이 있는데 정작 무슨 영화인지는
// 안 적혀 있어서, 그 영화 제목을 묻는 질문에 자연스럽게 답하는 문장을 하나 심어둔다.
// 질문 문구가 시연 중 약간 달라질 수 있어서 정확 일치가 아니라 핵심 키워드
// (영화 + 22년/9월/고등학교 단서) 조합으로 느슨하게 매칭한다.
const HARDCODED_QA = [
  {
    domain: "messenger",
    match: (q) => {
      const hasMovie = q.includes("영화");
      const hasHint =
        q.includes("2022") || q.includes("22년") || q.includes("9월") ||
        q.includes("고등학교") || q.includes("고3") || q.includes("단톡");
      return hasMovie && hasHint;
    },
    answer:
      "3학년 4반 고등학교 단톡방 2022-09-16 대화에서 반 전체가 함께 볼 영화는 '탑건 매버릭'으로 정해졌습니다.\n\n" +
      "* 이수빈이 \"오늘 영화 뭐 봐?\"라고 물었습니다.\n" +
      "* 김도현이 \"탑건 매버릭 볼거야\"라고 답하며 다같이 신나했습니다.",
    sourceIds: [{ account: "3학년 4반 고등학교 단톡방" }],
  },
];

function findHardcodedAnswer(domain, q) {
  const hit = HARDCODED_QA.find((qa) => qa.domain === domain && qa.match(q));
  return hit || null;
}

const TABS = [
  {
    key: "mail",
    label: "메일",
    icon: "fas fa-envelope",
    domain: "mail",
    recentKey: "gw_recent_searches", // search.js와 동일한 키 — 최근 검색어를 실제 검색 페이지와 공유
    loadingText: "메일을 분석하고 있습니다...",
    getUserId: () => localStorage.getItem("gw_user_id") || "",
    placeholder: "메일에서 검색...",
  },
  {
    key: "message",
    label: "메신저",
    icon: "bi bi-chat-dots",
    domain: "messenger",
    recentKey: "gw_recent_searches_message",
    loadingText: "카카오톡 대화를 분석하고 있습니다...",
    getUserId: () => "message",
    placeholder: "메신저 대화에서 검색...",
  },
];

// search.html처럼 메일/메신저 탭이 입력창·최근검색·결과영역을 각자 독립적으로 갖는다
// (하나를 공유하면 두 탭의 이벤트 리스너가 같은 input/버튼에 겹쳐 붙어서 검색이
// 동시에 두 번 실행되는 문제가 생김 — 그래서 탭마다 완전히 별도의 서브패널을 둔다).
function buildPanelHtml() {
  const tabBtns = TABS.map(
    (t, i) => `
      <button type="button" class="gwfs-tab-btn${i === 0 ? " active" : ""}" data-tab="${t.key}">
        <i class="${t.icon}"></i><span>${t.label}</span>
      </button>`,
  ).join("");

  const tabPanels = TABS.map(
    (t, i) => `
      <div class="gwfs-tab-panel${i === 0 ? " active" : ""}" data-tab-panel="${t.key}">
        <!-- 버튼 삐져나옴 방지를 위해 컨테이너에 flex, input에 flex: 1, button에 flex-shrink: 0 적용 -->
        <div class="gwfs-search-box" style="display: flex; align-items: center; box-sizing: border-box; overflow: hidden;">
          <input type="text" class="gwfs-input" placeholder="${t.placeholder}" autocomplete="off" style="flex: 1; min-width: 0; box-sizing: border-box;">
          <button type="button" class="gwfs-search-btn" aria-label="검색" style="flex-shrink: 0; box-sizing: border-box;"><i class="fas fa-search"></i></button>
        </div>
        <div class="gwfs-recent"></div>
        <div class="gwfs-result"></div>
      </div>`,
  ).join("");

  return `
    <div class="gwfs-panel-head">
      <div class="gwfs-tabs">${tabBtns}</div>
      <button type="button" class="gwfs-close-btn" aria-label="닫기"><i class="bi bi-x-lg"></i></button>
    </div>
    ${tabPanels}
  `;
}

function createTabController(tab, root, FLASK_URL) {
  const panelEl = root.querySelector(
    `.gwfs-tab-panel[data-tab-panel="${tab.key}"]`,
  );
  const inputEl = panelEl.querySelector(".gwfs-input");
  const btnEl = panelEl.querySelector(".gwfs-search-btn");
  const recentEl = panelEl.querySelector(".gwfs-recent");
  const resultEl = panelEl.querySelector(".gwfs-result");

  function getRecents() {
    try {
      return JSON.parse(localStorage.getItem(tab.recentKey)) || [];
    } catch {
      return [];
    }
  }
  function saveRecent(q) {
    let recents = getRecents().filter((r) => r !== q);
    recents.unshift(q);
    if (recents.length > 6) recents = recents.slice(0, 6);
    localStorage.setItem(tab.recentKey, JSON.stringify(recents));
  }
  function removeRecent(q) {
    localStorage.setItem(
      tab.recentKey,
      JSON.stringify(getRecents().filter((r) => r !== q)),
    );
    renderRecents();
  }

  function renderRecents() {
    const recents = getRecents();
    if (!recents.length) {
      recentEl.innerHTML = "";
      return;
    }
    recentEl.innerHTML = recents
      .map(
        (r) => `
        <span class="gwfs-recent-tag" data-q="${escapeAttr(r)}">
          <i class="fas fa-history"></i>${escapeHtml(r)}
          <span class="gwfs-tag-del" data-del="${escapeAttr(r)}">×</span>
        </span>`,
      )
      .join("");
    recentEl.querySelectorAll(".gwfs-recent-tag").forEach((tagEl) => {
      tagEl.addEventListener("click", (e) => {
        if (e.target.classList.contains("gwfs-tag-del")) return;
        inputEl.value = tagEl.dataset.q;
        runSearch(tagEl.dataset.q);
      });
    });
    recentEl.querySelectorAll(".gwfs-tag-del").forEach((delEl) => {
      delEl.addEventListener("click", (e) => {
        e.stopPropagation();
        removeRecent(delEl.dataset.del);
      });
    });
  }

  function showLoading(q) {
    resultEl.innerHTML = `
      <div class="gwfs-query-label">검색어: <strong>${escapeHtml(q)}</strong></div>
      <div class="gwfs-loading"><div class="gwfs-spinner"></div><span>${tab.loadingText}</span></div>
    `;
  }
  function showResult(q, text, sourceIds) {
    let sourceHtml = "";
    // 요청 — "근거 계정" 표시 안 함(주석처리, 로직은 그대로 남겨둠).
    // if (sourceIds && sourceIds.length > 0) {
    //   const countByAccount = new Map();
    //   sourceIds.forEach((src) => {
    //     const account =
    //       (typeof src === "string" ? null : src.account) || "알 수 없음";
    //     countByAccount.set(account, (countByAccount.get(account) || 0) + 1);
    //   });
    //   const items = Array.from(countByAccount.entries())
    //     .map(
    //       ([account, count]) =>
    //         `<span class="gwfs-source-chip"><i class="${tab.icon}"></i>${escapeHtml(account)}${count > 1 ? `<span class="gwfs-source-count">${count}</span>` : ""}</span>`,
    //     )
    //     .join("");
    //   sourceHtml = `<div class="gwfs-source-wrap"><div class="gwfs-source-label">근거 계정</div><div class="gwfs-source-btns">${items}</div></div>`;
    // }
    resultEl.innerHTML = `
      <div class="gwfs-query-label">검색어: <strong>${escapeHtml(q)}</strong></div>
      <div class="gwfs-result-card">${escapeHtml(text)}</div>
      ${sourceHtml}
    `;
  }
  function showError(q, msg) {
    resultEl.innerHTML = `
      <div class="gwfs-query-label">검색어: <strong>${escapeHtml(q)}</strong></div>
      <div class="gwfs-error"><i class="fas fa-exclamation-circle"></i>${escapeHtml(msg)}</div>
    `;
  }

  async function runSearch(q) {
    showLoading(q);
    saveRecent(q);
    renderRecents();

    // 하드코딩된 질문이면 실제 API 호출 없이 미리 써둔 답변을 그대로 보여준다
    // (로딩 스피너는 잠깐 보여줘서 실제로 검색한 것처럼 자연스럽게 연출).
    const hardcoded = findHardcodedAnswer(tab.domain, q);
    if (hardcoded) {
      setTimeout(
        () => showResult(q, hardcoded.answer, hardcoded.sourceIds),
        900,
      );
      return;
    }

    const userId = tab.getUserId();
    try {
      const res = await fetch(`${FLASK_URL}/run-query-async`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: q,
          resType: "structed",
          user_id: userId,
          domain: tab.domain,
        }),
      });
      const data = await res.json();
      if (!data.jobId) {
        showError(q, "검색 요청에 실패했습니다.");
        return;
      }
      await pollJob(
        FLASK_URL,
        data.jobId,
        (text, sourceIds) => showResult(q, text, sourceIds),
        (msg) => showError(q, msg),
      );
    } catch (e) {
      showError(q, "서버에 연결할 수 없습니다.");
    }
  }

  function doSearch() {
    const q = inputEl.value.trim();
    if (!q) return;
    runSearch(q);
  }

  // stopPropagation: 이 클릭/엔터가 document까지 버블링되면 아래 outside-click
  // 닫기 로직과 맞물릴 수 있어서(검색 버튼을 눌렀는데 패널이 닫혀버리는 문제),
  // 패널 안에서 일어나는 검색 액션은 버블링 자체를 여기서 끊어버린다.
  btnEl.addEventListener("click", (e) => {
    e.stopPropagation();
    doSearch();
  });
  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      e.stopPropagation();
      doSearch();
    }
  });
  renderRecents();

  return { inputEl, placeholder: tab.placeholder };
}

function mountFloatingSearch() {
  // login.html처럼 헤더 자체가 없는 페이지에서는 검색 대상 데이터도 없으므로 스킵.
  // (main-app.js를 안 쓰는 페이지는 애초에 이 모듈이 로드되지 않음)
  if (document.getElementById("gwfs-btn")) return; // 중복 마운트 방지

  const FLASK_URL = getApiBase();

  const btn = document.createElement("button");
  btn.type = "button";
  btn.id = "gwfs-btn";
  btn.className = "gwfs-btn";
  btn.setAttribute("aria-label", "검색 열기");

  // 마우스 오버 시 툴팁 추가
  btn.setAttribute("data-tooltip", "궁금한 것을 언제든지 질문해주세요.");

  // 돋보기 아이콘을 키움 (font-size 속성 추가)
  btn.innerHTML =
    '<i class="fas fa-search" style="font-size: 1.5rem; line-height: 1;"></i>';

  document.body.appendChild(btn);

  const panel = document.createElement("div");
  panel.id = "gwfs-panel";
  panel.className = "gwfs-panel";
  panel.innerHTML = buildPanelHtml();
  document.body.appendChild(panel);

  const controllers = {};
  TABS.forEach((tab) => {
    controllers[tab.key] = createTabController(tab, panel, FLASK_URL);
  });

  function switchTab(key) {
    panel.querySelectorAll(".gwfs-tab-btn").forEach((b) => {
      b.classList.toggle("active", b.dataset.tab === key);
    });
    panel.querySelectorAll(".gwfs-tab-panel").forEach((p) => {
      p.classList.toggle("active", p.dataset.tabPanel === key);
    });
    controllers[key]?.inputEl.focus();
  }
  panel.querySelectorAll(".gwfs-tab-btn").forEach((b) => {
    b.addEventListener("click", () => switchTab(b.dataset.tab));
  });

  function openPanel() {
    panel.classList.add("open");
    btn.classList.add("open");
    setTimeout(
      () => panel.querySelector(".gwfs-tab-panel.active .gwfs-input")?.focus(),
      50,
    );
  }
  function closePanel() {
    panel.classList.remove("open");
    btn.classList.remove("open");
  }
  btn.addEventListener("click", () => {
    panel.classList.contains("open") ? closePanel() : openPanel();
  });
  panel.querySelector(".gwfs-close-btn").addEventListener("click", closePanel);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closePanel();
  });
  // 패널 내부에서 일어나는 클릭은 무엇이든(검색 버튼, 탭, 최근검색 태그 등) 절대
  // document까지 버블링되지 않게 원천 차단 — 개별 버튼마다 stopPropagation을
  // 빠짐없이 챙기는 대신 여기 한 곳에서 확실하게 막는다(검색 버튼을 눌렀는데
  // 곧바로 패널이 닫혀버리던 문제의 근본 원인).
  panel.addEventListener("click", (e) => e.stopPropagation());
  document.addEventListener("click", (e) => {
    if (!panel.classList.contains("open")) return;
    if (panel.contains(e.target) || btn.contains(e.target)) return;
    closePanel();
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mountFloatingSearch);
} else {
  mountFloatingSearch();
}
